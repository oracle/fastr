vanilla <-
function() print("A vanilla R package")
